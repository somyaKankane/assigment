export const environment = {
  production: true,
  version: '0.0.1',
  build: 27,
  apiBaseUrl: ' https://api.github.com/',
  apiProxy: '',
 
  platform: 'web',
  
 
  showBuild: true
};

